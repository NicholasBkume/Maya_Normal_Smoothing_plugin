Requires Abnormal Maya 0.1.2 installed in Maya 2024+.
In Maya Python Script Editor:
import runpy
runpy.run_path(r"C:/path/to/run_all_maya.py")["run"]()

Automated results are printed. The modeless checklist covers actual mouse input
and visual inspection. Close it to clean up its own test cube. Tests do not
reset/save the scene. They do add Maya undo-history entries.
