Requires Abnormal Maya 0.2.0. In Maya Python:
import runpy
runpy.run_path(r"C:/path/to/run_all_maya.py")["run"]()
