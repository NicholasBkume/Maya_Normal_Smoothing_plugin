Requires Abnormal Maya 0.2.1. Restart Maya before testing the updated draw plugin.
In Maya Python:
import runpy
runpy.run_path(r"C:/path/to/run_all_maya.py")["run"]()
