Requires Abnormal Maya 0.9.0. Restart Maya before testing updated modules and the draw plugin.
In Maya Python:
import runpy
runpy.run_path(r"C:/path/to/run_all_maya.py")["run"]()

The full distribution includes this runner. It has 26 automated cases and 12
manual checks. New features require Maya runtime validation.
